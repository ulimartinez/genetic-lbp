package Test;

public interface Dialogue {

}
